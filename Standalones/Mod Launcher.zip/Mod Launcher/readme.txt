This Tool Is Part Of A Collection Of Python Based Tools For Modding Empire At War Developed By Kiwi


this is a fairly self explanatory piece of software
it is capable of launching mods, and submods for Empire At War Forces Of Corruption, as well as installing its debug build
and adding extra launch parameters, and creating shortcuts for mod launching