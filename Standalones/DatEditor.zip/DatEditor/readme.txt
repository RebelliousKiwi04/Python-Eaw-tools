This Tool Is Part Of A Collection Of Python Based Tools For Modding Empire At War Developed By Kiwi


credit to Jorrit for his freely available dat compiler of which some of the code for this is based off of
The name is fairly self explanatory this is a piece of software designed to edit Petryoglyph text files
after opening the executable go to File->Open to open a dat file, the table will then fill, to edit an identifier or string double click on it
To search through the dat file type something into the search bar, then press the search icon
to add a new text string go to New-> Text String, this will create an empty cell at the top of the table for you to edit
to save the dat file, go to File->Save or Save As