This Tool Is Part Of A Collection Of Python Based Tools For Modding Empire At War Developed By Kiwi
This tool is a planet placement tool with the ability to change other planet details as well
after launching select the Data Folder of any mod, you will then be greeted by the main UI for the application
To Move a planet simply drag and drop the orange dot on the map
To Increase the size of the orange dot, click the Set Point Size Button at the top of the page, and enter a new value
To Zoom in on the map, click the magnifying glass above the map and draw a square on the map
To Reset your map view, press the home Button above the map
To view what planet isw what on the map, hover above the blue dots on the map, the planet name should appear
To Change selected planet either click ona  blue dot on the map, or select another planet from the dropdown near the top right
To Save an image of the map click the save button above the map
To Edit any of the planet information (Map, model) click on the ... buttons to the right of the sections in the left of the UI
To Save Changes to file, press the Save To File button in the top of the UI - WARNING THIS WILL SAVE ALL CHANGES TO ALL EDITED PLANETS, to revert changes, press the reset planet position button with the desired planet selected
To Reset the planet position back to its original point, press the Reset Planet Position button
